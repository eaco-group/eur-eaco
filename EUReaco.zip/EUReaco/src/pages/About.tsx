import { useState } from 'react';
import { useLanguage } from '@/contexts/languageContext.tsx';
import CopyToClipboard from 'react-copy-to-clipboard';
import { toast } from 'sonner';

// 社区链接数据
const communityLinks = [
  {
    id: 1,
    name: "X.com",
    url: "https://x.com/eacocc",
    icon: "fa-twitter",
    color: "bg-sky-500"
  },
  {
    id: 2,
    name: "English TG",
    url: "https://t.me/e_eacocc",
    icon: "fa-telegram",
    color: "bg-blue-500"
  },
  {
    id: 3,
    name: "华语社区",
    url: "https://t.me/aieaco",
    icon: "fa-comments",
    color: "bg-green-500"
  },
  {
    id: 4,
    name: "Spanish Group",
    url: "https://t.me/eacoespanish",
    icon: "fa-comments",
    color: "bg-red-500"
  },
  {
    id: 5,
    name: "中文TG",
    url: "https://t.me/eacocny",
    icon: "fa-telegram",
    color: "bg-blue-500"
  },
  {
    id: 6,
    name: "Vietnam TG",
    url: "https://t.me/e_vietnam",
    icon: "fa-telegram",
    color: "bg-blue-500"
  },
  {
    id: 7,
    name: "USDC TG",
    url: "https://t.me/e_usdc",
    icon: "fa-telegram",
    color: "bg-blue-500"
  },
  {
    id: 8,
    name: "Indonesia TG",
    url: "https://t.me/e_indonesia",
    icon: "fa-telegram",
    color: "bg-blue-500"
  }
];

// 交易平台数据
const tradingPlatforms = [
  {
    id: 1,
    name: "Meteora (e-usdt)",
    url: "https://app.meteora.ag/dlmm/6ZfCi3qzhgDN1ygHVYXvfsfrwz8ZhQ7hD5mJtjeuUDyE",
    icon: "fa-exchange-alt",
    color: "bg-purple-500"
  },
  {
    id: 2,
    name: "Orca (e-usdc)",
    url: "https://www.orca.so/pools/Cm6EkxcYNfvxeYDBQ3TGXFqa9NCWvrFKHz4Cfju91dhr",
    icon: "fa-exchange-alt",
    color: "bg-blue-500"
  },
  {
    id: 3,
    name: "Raydium (e-sol)",
    url: "https://raydium.io/swap/?inputMint=DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH&outputMint=sol",
    icon: "fa-exchange-alt",
    color: "bg-gradient-to-r from-pink-500 to-orange-500"
  },
  {
    id: 4,
    name: "CoinMarketCap",
    url: "https://dex.coinmarketcap.com/token/solana/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH/",
    icon: "fa-chart-line",
    color: "bg-blue-600"
  },
  {
    id: 5,
    name: "DexScreener",
    url: "https://dexscreener.com/solana/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
    icon: "fa-chart-bar",
    color: "bg-indigo-600"
  },
  {
    id: 6,
    name: "OKX",
    url: "https://web3.okx.com/token/solana/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
    icon: "fa-link",
    color: "bg-red-600"
  },
  {
    id: 7,
    name: "Binance",
    url: "https://web3.binance.com/en/token/sol/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
    icon: "fa-link",
    color: "bg-yellow-500"
  },
  {
    id: 8,
    name: "Solscan",
    url: "https://solscan.io/token/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
    icon: "fa-search",
    color: "bg-slate-700"
  }
];

// 官方链接数据
const officialLinks = [
  {
    id: 1,
    name: "Linktree",
    url: "https://linktr.ee/web3eaco",
    icon: "fa-link",
    color: "bg-gradient-to-r from-purple-500 to-pink-500"
  },
  {
    id: 2,
    name: "EACO CCNY",
    url: "https://linktr.ee/eacocc",
    icon: "fa-link",
    color: "bg-gradient-to-r from-blue-500 to-teal-500"
  },
  {
    id: 3,
    name: "E Swap GitHub",
    url: "https://github.com/eacocc/EACO_Exchange_DApp",
    icon: "fa-github",
    color: "bg-gray-900"
  },
  {
    id: 4,
    name: "OKLink",
    url: "https://www.oklink.com/zh-hans/solana/token/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
    icon: "fa-link",
    color: "bg-blue-600"
  }
];

export default function About() {
  const { language, t } = useLanguage();
  const [copied, setCopied] = useState(false);
  const contractAddress = "DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH";
  
  const handleCopy = () => {
    toast.success("合约地址已复制");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold text-xl">E</span>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">EUR eaco</h1>
          </div>
          <div className="flex items-center space-x-4">
            <a 
              href="/" 
              className="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              <i className="fa-solid fa-arrow-left mr-1"></i> 返回首页
            </a>
            <a 
              href="/faq" 
              className="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              <i className="fa-solid fa-question-circle mr-1"></i> 帮助
            </a>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* 英雄区域 */}
        <section className="mb-16 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
            {t('about.title')}
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
            {t('about.hero_subtitle')}
          </p>
          
          <div className="mt-10 relative w-full max-w-4xl mx-auto h-64 md:h-80 rounded-2xl overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-emerald-500/90 flex items-center justify-center">
              <div className="text-white text-center px-6">
                <h3 className="text-3xl md:text-4xl font-bold mb-4">EACO</h3>
                <p className="text-xl md:text-2xl italic">"Earth's Best Coin"</p>
                <p className="mt-4 text-lg">连接地球和宇宙万物的文明协议</p>
              </div>
            </div>
          </div>
        </section>

        {/* 关于EACO部分 */}
        <section className="mb-16 max-w-4xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-slate-800 dark:text-slate-200">
            {t('about.what_is_eaco')}
          </h2>
          
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 md:p-8 border border-slate-100 dark:border-slate-700">
            <p className="text-lg text-slate-700 dark:text-slate-300 leading-relaxed mb-6">
              {t('about.eaco_description')}
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="bg-slate-50 dark:bg-slate-700/50 p-5 rounded-xl transition-all duration-300 hover:shadow-md">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center mb-4">
                  <i className="fa-solid fa-code text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
                <h3 className="font-bold text-lg mb-2 text-slate-800 dark:text-slate-200">{t('about.code_wealth')}</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm">{t('about.code_wealth_desc')}</p>
              </div>
              
              <div className="bg-slate-50 dark:bg-slate-700/50 p-5 rounded-xl transition-all duration-300 hover:shadow-md">
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center mb-4">
                  <i className="fa-solid fa-globe text-green-600 dark:text-green-400 text-xl"></i>
                </div>
                <h3 className="font-bold text-lg mb-2 text-slate-800 dark:text-slate-200">{t('about.earth_best_friend')}</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm">{t('about.earth_best_friend_desc')}</p>
              </div>
              
              <div className="bg-slate-50 dark:bg-slate-700/50 p-5 rounded-xl transition-all duration-300 hover:shadow-md">
                <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center mb-4">
                  <i className="fa-solid fa-calculator text-purple-600 dark:text-purple-400 text-xl"></i>
                </div>
                <h3 className="font-bold text-lg mb-2 text-slate-800 dark:text-slate-200">{t('about.labor_value')}</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm">{t('about.labor_value_desc')}</p>
              </div>
            </div>
          </div>
        </section>

        {/* 代币信息部分 */}
        <section className="mb-16 max-w-4xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-slate-800 dark:text-slate-200">
            {t('about.token_info')}
          </h2>
          
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 md:p-8 border border-slate-100 dark:border-slate-700">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-300">{t('about.total_supply')}</h3>
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">1,350,000,000</div>
                <p className="text-slate-500 dark:text-slate-400 mt-1">EACO</p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-300">{t('about.contract_address')}</h3>
                <div className="flex items-center bg-slate-100 dark:bg-slate-700 rounded-lg p-3 font-mono text-sm">
                  <span className="truncate max-w-md">{contractAddress}</span>
                  <CopyToClipboard text={contractAddress} onCopy={handleCopy}>
                    <button className="ml-3 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                      <i className="fa-solid fa-copy"></i>
                    </button>
                  </CopyToClipboard>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm mt-2">Solana Blockchain</p>
              </div>
            </div>
          </div>
        </section>

        {/* 社区链接部分 */}
        <section className="mb-16 max-w-5xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-slate-800 dark:text-slate-200">
            {t('about.community_links')}
          </h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {communityLinks.map((link) => (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative overflow-hidden rounded-xl shadow-md transition-all duration-300 hover:shadow-lg"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 opacity-80 group-hover:opacity-90 transition-opacity"></div>
                <div className="relative p-5 h-full flex flex-col items-center justify-center text-center">
                  <div className={`w-12 h-12 rounded-full ${link.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    <i className={`fa-brands ${link.icon} text-white text-xl`}></i>
                  </div>
                  <h3 className="text-white font-medium mb-1">{link.name}</h3>
                  <span className="text-xs text-slate-300 group-hover:text-white transition-colors">
                    {new URL(link.url).hostname}
                  </span>
                </div>
              </a>
            ))}
          </div>
        </section>

        {/* 交易平台部分 */}
        <section className="mb-16 max-w-5xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-slate-800 dark:text-slate-200">
            {t('about.trading_platforms')}
          </h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {tradingPlatforms.map((platform) => (
              <a
                key={platform.id}
                href={platform.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative overflow-hidden rounded-xl shadow-md transition-all duration-300 hover:shadow-lg"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 opacity-80 group-hover:opacity-90 transition-opacity"></div>
                <div className="relative p-5 h-full flex flex-col items-center justify-center text-center">
                  <div className={`w-12 h-12 rounded-full ${platform.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    <i className={`fa-solid ${platform.icon} text-white text-xl`}></i>
                  </div>
                  <h3 className="text-white font-medium mb-1 text-sm">{platform.name}</h3>
                  <span className="text-xs text-slate-300 group-hover:text-white transition-colors truncate">
                    {new URL(platform.url).hostname}
                  </span>
                </div>
              </a>
            ))}
          </div>
        </section>

        {/* 官方链接部分 */}
        <section className="mb-16 max-w-5xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-slate-800 dark:text-slate-200">
            {t('about.official_links')}
          </h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {officialLinks.map((link) => (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative overflow-hidden rounded-xl shadow-md transition-all duration-300 hover:shadow-lg"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 opacity-80 group-hover:opacity-90 transition-opacity"></div>
                <div className="relative p-5 h-full flex flex-col items-center justify-center text-center">
                  <div className={`w-12 h-12 rounded-full ${link.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    <i className={`fa-brands ${link.icon} text-white text-xl`}></i>
                  </div>
                  <h3 className="text-white font-medium mb-1 text-sm">{link.name}</h3>
                  <span className="text-xs text-slate-300 group-hover:text-white transition-colors truncate">
                    {new URL(link.url).hostname}
                  </span>
                </div>
              </a>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-slate-100 dark:bg-slate-800 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-600 dark:text-slate-400 mb-4">
            © 2025 EACO Earth Asset Civilization Oracle. {t('common.copyright')}
          </p>
          <div className="flex justify-center space-x-4 mt-4">
            <a href="https://x.com/eacocc" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors">
              <i className="fa-brands fa-twitter"></i>
            </a>
            <a href="https://t.me/e_eacocc" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors">
              <i className="fa-brands fa-telegram"></i>
            </a>
            <a href="https://github.com/eacocc/EACO_Exchange_DApp" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors">
              <i className="fa-brands fa-github"></i>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}