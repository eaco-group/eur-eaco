import { useState, useEffect } from 'react';
import { useLanguage } from '@/contexts/languageContext.tsx';
import { FAQItem, faqData, modules } from '@/lib/faqData';

export default function FAQ() {
  const { language, t } = useLanguage();
  const [activeModule, setActiveModule] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [displayedFAQs, setDisplayedFAQs] = useState<FAQItem[]>(faqData);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // 过滤FAQ
  useEffect(() => {
    let filtered = faqData;
    
    // 模块过滤
    if (activeModule !== 'all') {
      filtered = filtered.filter(faq => faq.module === activeModule);
    }
    
    // 搜索过滤
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(faq => 
        faq.question[language as keyof typeof faq.question].toLowerCase().includes(query) ||
        faq.answer[language as keyof typeof faq.answer].toLowerCase().includes(query) ||
        faq.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    setDisplayedFAQs(filtered);
    // 默认收起所有展开项
    setExpandedId(null);
  }, [activeModule, searchQuery, language]);

  // 切换展开/收起状态
  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };
  
  // 获取当前语言的模块名称
  const getModuleName = (moduleId: string) => {
    const module = modules.find(m => m.id === moduleId);
    if (!module) return '';
    
    switch(language) {
      case 'zh': return module.names.zh;
      case 'en': return module.names.en;
      case 'es': return module.names.es;
      case 'vi': return module.names.vi;
      default: return module.names.en;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold text-xl">E</span>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">EUR eaco</h1>
          </div>
          <div className="flex items-center">
            <a 
              href="/" 
              className="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors mr-6"
            >
              <i className="fa-solid fa-arrow-left mr-1"></i> 返回首页
            </a>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* FAQ头部 */}
        <section className="mb-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
            {language === 'zh' ? 'EACO常见问题' : 
             language === 'en' ? 'EACO FAQ' : 
             language === 'es' ? 'Preguntas frecuentes de EACO' : 
             'Câu hỏi thường gặp về EACO'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            {language === 'zh' ? '这里是关于EACO协议、钱包使用、Swap操作等方面的常见问题解答，如有其他疑问，请联系我们的客服团队。' : 
             language === 'en' ? 'Here are answers to common questions about the EACO protocol, wallet usage, Swap operations, and more. For other questions, please contact our support team.' : 
             language === 'es' ? 'Aquí encontrará respuestas a preguntas frecuentes sobre el protocolo EACO, uso de billetera, operaciones Swap y más. Para otras preguntas, contáctenos con nuestro equipo de soporte.' : 
             'Đây là câu trả lời cho các câu hỏi thường gặp về giao thức EACO, cách sử dụng ví, thao tác Swap và nhiều hơn nữa. Đối với các câu hỏi khác, vui lòng liên hệ đội hỗ trợ của chúng tôi.'}
          </p>
        </section>
        
        {/* 搜索框 */}
        <section className="mb-8">
          <div className="relative max-w-2xl mx-auto">
            <input
              type="text"
              placeholder={language === 'zh' ? '搜索问题...' : 
                      language === 'en' ? 'Search questions...' : 
                      language === 'es' ? 'Buscar preguntas...' : 
                      'Tìm kiếm câu hỏi...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-5 py-3 pl-12 rounded-full border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
            <i className="fa-solid fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400"></i>
            
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              >
                <i className="fa-solid fa-times-circle"></i>
              </button>
            )}
          </div>
        </section>
        
        {/* 模块筛选 */}
        <section className="mb-10 overflow-x-auto pb-2">
          <div className="flex space-x-2 min-w-max justify-center">
            <button
              onClick={() => setActiveModule('all')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeModule === 'all'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              {language === 'zh' ? '全部' : 
               language === 'en' ? 'All' : 
               language === 'es' ? 'Todo' : 
               'Tất cả'}
            </button>
            
            {modules.map((module) => (
              <button
                key={module.id}
                onClick={() => setActiveModule(module.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                  activeModule === module.id
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                {module.names[language as keyof typeof module.names]}
              </button>
            ))}
          </div>
        </section>
        
        {/* 结果统计 */}
        <section className="mb-6 text-center">
          <p className="text-slate-600 dark:text-slate-400 text-sm">
            {language === 'zh' ? `找到 ${displayedFAQs.length} 个结果` : 
             language === 'en' ? `${displayedFAQs.length} results found` : 
             language === 'es' ? `${displayedFAQs.length} resultados encontrados` : 
             `Tìm thấy ${displayedFAQs.length} kết quả`}
            
            {activeModule !== 'all' && (
              <>
                {' - '}
                <span className="font-medium">
                  {getModuleName(activeModule)}
                </span>
              </>
            )}
            
            {searchQuery && (
              <>
                {' - '}
                <span className="font-medium">"{searchQuery}"</span>
              </>
            )}
          </p>
        </section>
        
        {/* FAQ列表 */}
        <section className="max-w-4xl mx-auto">
          {displayedFAQs.length === 0 ? (
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400">
                <i className="fa-solid fa-search text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-700 dark:text-slate-300">
                {language === 'zh' ? '未找到结果' : 
                 language === 'en' ? 'No results found' : 
                 language === 'es' ? 'No se encontraron resultados' : 
                 'Không tìm thấy kết quả'}
              </h3>
              <p className="text-slate-500 dark:text-slate-400 mb-6">
                {language === 'zh' ? '尝试使用不同的搜索词或浏览其他模块' : 
                 language === 'en' ? 'Try using different search terms or browse other modules' : 
                 language === 'es' ? 'Intente usar diferentes términos de búsqueda o explore otras módulos' : 
                 'Hãy thử sử dụng các từ khóa tìm kiếm khác hoặc duyệt các mô-đun khác'}
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveModule('all');
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-sm font-medium transition-colors"
              >
                <i className="fa-solid fa-refresh mr-1"></i>
                {language === 'zh' ? '重置筛选条件' : 
                 language === 'en' ? 'Reset filters' : 
                 language === 'es' ? 'Restablecer filtros' : 
                 'Đặt lại bộ lọc'}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {displayedFAQs.map((faq) => (
                <div 
                  key={faq.id}
                  className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg border border-slate-100 dark:border-slate-700"
                >
                  <button
                    className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none"
                    onClick={() => toggleExpand(faq.id)}
                  >
                    <span className="font-semibold text-lg text-slate-800 dark:text-slate-200">
                      {faq.question[language as keyof typeof faq.question]}
                    </span>
                    <i className={`fa-solid ${expandedId === faq.id ? 'fa-chevron-up' : 'fa-chevron-down'} text-slate-400 transition-transform duration-300`}></i>
                  </button>
                  
                  <div 
                    className={`px-6 pb-4 overflow-hidden transition-all duration-300 ${
                      expandedId === faq.id ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                    }`}
                  >
                    <div className="text-slate-600 dark:text-slate-300 leading-relaxed">
                      {faq.answer[language as keyof typeof faq.answer]}
                    </div>
                    
                    <div className="mt-4 flex flex-wrap gap-2">
                      {faq.tags.map((tag) => (
                        <span 
                          key={tag}
                          className="px-2 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
        
        {/* 返回顶部按钮 */}
        {displayedFAQs.length > 0 && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-6 right-6 bg-blue-600 hover:bg-blue-700 text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-110"
          >
            <i className="fa-solid fa-chevron-up"></i>
          </button>
        )}
      </main>
      
      <footer className="bg-slate-100 dark:bg-slate-800 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-600 dark:text-slate-400 mb-4">
            {language === 'zh' ? '还有其他问题？请联系我们的客服团队' : 
             language === 'en' ? 'Have other questions? Contact our support team' : 
             language === 'es' ? '¿Tiene otras preguntas? Contacte a nuestro equipo de soporte' : 
             'Có câu hỏi khác? Liên hệ đội hỗ trợ của chúng tôi'}
          </p>
          <a
            href="mailto:support@eaco.org"
            className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline font-medium"
          >
            <i className="fa-solid fa-envelope mr-2"></i>
            support@eaco.org
          </a>
          
          <p className="mt-6 text-slate-500 dark:text-slate-400 text-sm">
            © 2025 EACO Earth Asset Civilization Oracle. {language === 'zh' ? '保留所有权利' : 
                                                      language === 'en' ? 'All rights reserved' : 
                                                      language === 'es' ? 'Todos los derechos reservados' : 
                                                      'Tất cả quyền được bảo lưu'}
          </p>
        </div>
      </footer>
    </div>
  );
}