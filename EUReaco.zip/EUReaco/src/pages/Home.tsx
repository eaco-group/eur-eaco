import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import PriceCard from '@/components/PriceCard';
import ExchangeMethods from '@/components/ExchangeMethods';
import LinksSection from '@/components/LinksSection';
import CommunitySection from '@/components/CommunitySection';
import { getEACOPrice, getHistoricalData } from '@/lib/eacoData';
import { useLanguage, languageNames, languageFlags } from '@/contexts/languageContext.tsx';

export default function Home() {
  const [price, setPrice] = useState<number>(0);
  const [change, setChange] = useState<number>(0);
  const [historicalData, setHistoricalData] = useState([]);
  const [loading, setLoading] = useState(true);
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    // 获取初始价格数据
    const fetchInitialData = async () => {
      setLoading(true);
      const priceData = getEACOPrice();
      const chartData = getHistoricalData();
      
      setPrice(priceData.price);
      setChange(priceData.change);
      setHistoricalData(chartData);
      setLoading(false);
    };

    fetchInitialData();

    // 模拟价格更新
    const interval = setInterval(() => {
      const newPriceData = getEACOPrice();
      setPrice(newPriceData.price);
      setChange(newPriceData.change);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold text-xl">E</span>
            </div>
             <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">EUR eaco</h1>
          </div>
          <div className="flex items-center space-x-4">
            {/* 语言选择器 */}
            <div className="relative">
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg px-3 py-2 pr-8 appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {Object.entries(languageNames).map(([code, name]) => (
                  <option key={code} value={code}>
                    <i className={`fa-solid ${languageFlags[code as keyof typeof languageFlags]} mr-2`}></i>
                    {name}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
            
               <a 
                 href="/about" 
                 className="hidden md:flex items-center space-x-1 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
               >
                 <i className="fa-solid fa-info-circle"></i>
                 <span>{t('common.about')}</span>
               </a>
              <a 
                href="/faq" 
                className="hidden md:flex items-center space-x-1 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <i className="fa-solid fa-question-circle"></i>
                <span>{t('common.help')}</span>
              </a>
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full transition-all transform hover:scale-105 flex items-center">
              <i className="fa-solid fa-wallet mr-2"></i>
              <span>{t('common.connect_wallet')}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* 价格概览部分 */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('common.price')}</h2>
            <p className="text-slate-600 dark:text-slate-400">{t('common.real_time_price_and_market_data')}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <PriceCard 
              title={t('common.current_price')} 
              value={loading ? "加载中..." : `€${price.toFixed(4)}`} 
              change={change}
              icon="fa-line-chart"
            />
            <PriceCard 
              title={t('common.24h_volume')} 
              value={loading ? "加载中..." : `€${(price * 125000).toLocaleString()}`} 
              icon="fa-exchange-alt"
            />
            <PriceCard 
              title={t('common.total_supply')} 
              value="1,350,000,000 EACO" 
              icon="fa-coins"
            />
          </div>
          
          {/* 价格图表 */}
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-4 md:p-6">
            <h3 className="text-xl font-semibold mb-4">{t('common.price_chart_7d')}</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={historicalData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                      borderRadius: '12px',
                      boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
        
        {/* 兑换方法部分 */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('common.exchange_methods')}</h2>
            <p className="text-slate-600 dark:text-slate-400">{t('common.ways_to_convert_eur_to_eaco')}</p>
          </div>
          
          <ExchangeMethods />
        </section>
        
        {/* 交易链接部分 */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('common.trading_platforms')}</h2>
            <p className="text-slate-600 dark:text-slate-400">{t('common.trade_eaco_on')}</p>
          </div>
          
          <LinksSection />
        </section>
        
        {/* 社区部分 */}
        <section>
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('common.community_and_ecosystem')}</h2>
            <p className="text-slate-600 dark:text-slate-400">{t('common.join_eaco_community')}</p>
          </div>
          
          <CommunitySection />
        </section>
      </main>

       <footer className="bg-slate-100 dark:bg-slate-800 py-8 mt-12">
         <div className="container mx-auto px-4 text-center">
           <p className="text-slate-600 dark:text-slate-400">{t('common.copyright')}</p>
            <div className="flex justify-center space-x-4 mt-4">
              <a href="https://x.com/eacocc" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors">
                <i className="fa-brands fa-twitter"></i>
              </a>
              <a href="https://t.me/e_eacocc" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors">
                <i className="fa-brands fa-telegram"></i>
              </a>
              <a href="https://github.com/eacocc/EACO_Exchange_DApp" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors">
                <i className="fa-brands fa-github"></i>
              </a>
            </div>
           
           {/* 新增链接区域 */}
            <div className="mt-6 pt-6 border-t border-slate-300 dark:border-slate-700">

            </div>
         </div>
       </footer>
    </div>
  );
}