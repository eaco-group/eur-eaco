/**
 * FAQ数据 - 包含常见问题与答案，支持多语言
 */

export interface FAQItem {
  id: string;
  module: string;
  moduleName: {
    zh: string;
    en: string;
    es: string;
    vi: string;
  };
  question: {
    zh: string;
    en: string;
    es: string;
    vi: string;
  };
  answer: {
    zh: string;
    en: string;
    es: string;
    vi: string;
  };
  tags: string[];
}

// 模块列表
export const modules = [
  { 
    id: 'protocol', 
    names: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    }
  },
  { 
    id: 'wallet', 
    names: {
      zh: '钱包与Swap操作',
      en: 'Wallet & Swap Operations',
      es: 'Operaciones de billetera y Swap',
      vi: 'Ví và thao tác Swap'
    }
  },
  { 
    id: 'anchoring', 
    names: {
      zh: '跨链锚定机制',
      en: 'Cross-chain Anchoring',
      es: 'Anclaje entre cadenas',
      vi: 'Cơ chế neo chuỗi chéo'
    }
  },
  { 
    id: 'labor', 
    names: {
      zh: '劳动价值计算模型',
      en: 'Labor Value Model',
      es: 'Modelo de valor laboral',
      vi: 'Mô hình tính giá trị lao động'
    }
  },
  { 
    id: 'compliance', 
    names: {
      zh: '合规与政策接入',
      en: 'Compliance & Policy',
      es: 'Cumplimiento y política',
      vi: 'Tuân thủ và chính sách'
    }
  },
  { 
    id: 'community', 
    names: {
      zh: '多语种社区与教育',
      en: 'Community & Education',
      es: 'Comunidad y educación',
      vi: 'Cộng đồng và giáo dục'
    }
  },
  { 
    id: 'localization', 
    names: {
      zh: '国家专题与本地化应用',
      en: 'Country-specific Applications',
      es: 'Aplicaciones por país',
      vi: 'Ứng dụng theo quốc gia'
    }
  },
  { 
    id: 'development', 
    names: {
      zh: '开发者与生态建设',
      en: 'Development & Ecosystem',
      es: 'Desarrollo y ecosistema',
      vi: 'Phát triển và hệ sinh thái'
    }
  },
  { 
    id: 'nft', 
    names: {
      zh: '教育型NFT与激励',
      en: 'Educational NFTs & Incentives',
      es: 'NFT educativos e incentivos',
      vi: 'NFT giáo dục và khuyến khích'
    }
  },
  { 
    id: 'support', 
    names: {
      zh: '常见问题与技术支持',
      en: 'FAQs & Technical Support',
      es: 'Preguntas frecuentes y soporte',
      vi: 'Câu hỏi thường gặp và hỗ trợ kỹ thuật'
    }
  }
];

// FAQ数据
export const faqData: FAQItem[] = [
  // 模块1: EACO协议基础 (10题)
  {
    id: 'q001',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: '什么是EACO协议？',
      en: 'What is the EACO protocol?',
      es: '¿Qué es el protocolo EACO?',
      vi: 'Giao thức EACO là gì?'
    },
    answer: {
      zh: 'EACO是一个连接地球与宇宙万物的文明协议，它通过区块链技术实现劳动价值与资源的锚定，构建一个去中心化的价值交换网络。EACO协议旨在创建一个公平、透明、高效的全球价值交换系统，让每个人的劳动和资源都能得到合理的评估和回报。',
      en: 'EACO is a civilization protocol connecting Earth and the cosmos. It anchors labor value and resources through blockchain technology, building a decentralized value exchange network. The EACO protocol aims to create a fair, transparent, and efficient global value exchange system where everyone\'s labor and resources can receive reasonable evaluation and rewards.',
      es: 'EACO es un protocolo de civilización que conecta la Tierra con el cosmos. Ancla el valor laboral y los recursos a través de tecnología blockchain, construyendo una red descentralizada de intercambio de valor. El protocolo EACO pretende crear un sistema global de intercambio de valor justo, transparente y eficiente donde el trabajo y los recursos de cada persona puedan recibir una evaluación y recompensas razonables.',
      vi: 'EACO là một giao thức văn minh kết nối Trái Đất với vũ trụ. Nó neo giá trị lao động và tài nguyên thông qua công nghệ blockchain, xây dựng một mạng lưới trao đổi giá trị phi tập trung. Giao thức EACO nhằm tạo ra một hệ thống trao đổi giá trị toàn cầu công bằng, minh bạch và hiệu quả, nơi mà lao động và tài nguyên của mỗi người đều có thể nhận được đánh giá và phần thưởng hợp lý.'
    },
    tags: ['protocol', 'basic', 'definition']
  },
  {
    id: 'q002',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: '"e即财富"是什么意思？',
      en: 'What does "e equals wealth" mean?',
      es: '¿Qué significa "e es riqueza"?',
      vi: '"e là tài sản" nghĩa là gì?'
    },
    answer: {
      zh: '"e即财富"是EACO协议的核心理念，表明每个人的劳动和创造都具有价值，这些价值可以通过EACO系统被量化和转化为数字资产。这里的"e"代表电子(electronic)、平等(equality)和每个人(everyone)，象征着数字经济时代人人都能公平地参与价值创造和分配。',
      en: '"e equals wealth" is the core concept of the EACO protocol, indicating that everyone\'s labor and creation have value, which can be quantified and converted into digital assets through the EACO system. The "e" here represents electronic, equality, and everyone, symbolizing that in the digital economy era, everyone can fairly participate in value creation and distribution.',
      es: '"e es riqueza" es el concepto central del protocolo EACO, indicando que el trabajo y la creación de cada persona tienen valor, que puede cuantificarse y convertirse en activos digitales a través del sistema EACO. La "e" aquí representa electrónico, igualdad y todos, simbolizando que en la era de la economía digital, todos pueden participar fairly en la creación y distribución de valor.',
      vi: '"e là tài sản" là khái niệm cốt lõi của giao thức EACO, chỉ ra rằng lao động và sáng tạo của mỗi người đều có giá trị, giá trị này có thể được định lượng và chuyển đổi thành tài sản kỹ thuật số thông qua hệ thống EACO. "e" ở đây đại diện cho điện tử (electronic), bình đẳng (equality) và mọi người (everyone), tượng trưng cho thời đại kinh tế số mà mọi người đều có thể tham gia công bằng vào việc tạo ra và phân phối giá trị.'
    },
    tags: ['concept', 'philosophy', 'value']
  },
  {
    id: 'q003',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: 'EACO的总量是多少？',
      en: 'What is the total supply of EACO?',
      es: '¿Cuál es el suministro total de EACO?',
      vi: 'Tổng cung của EACO là bao nhiêu?'
    },
    answer: {
      zh: 'EACO的总供应量为13.5亿枚，这一数量是基于全球人口和经济规模经过科学计算确定的。EACO采用通胀模型，每年通胀率为2%，用于奖励生态建设者和维护系统安全，但同时也设有销毁机制，通过定期销毁部分代币来保持生态平衡。',
      en: 'The total supply of EACO is 1.35 billion tokens, a quantity scientifically determined based on global population and economic scale. EACO adopts an inflation model with an annual inflation rate of 2%, used to reward ecosystem builders and maintain system security. However, there is also a destruction mechanism to maintain ecological balance by periodically destroying some tokens.',
      es: 'La oferta total de EACO es de 1.350 millones de tokens, una cantidad determinada científicamente basada en la población global y la escala económica. EACO adopta un modelo de inflación con una tasa anual de inflación del 2%, utilizada para recompensar a los constructores del ecosistema y mantener la seguridad del sistema. Sin embargo, también existe un mecanismo de destrucción para mantener el equilibrio ecológico al destruir periódicamente algunos tokens.',
      vi: 'Tổng cung của EACO là 1,35 tỷ token, một số lượng được xác định khoa học dựa trên dân số toàn cầu và quy mô kinh tế. EACO áp dụng mô hình lạm phát với tỷ lệ lạm phát hàng năm là 2%, được sử dụng để thưởng các nhà xây dựng hệ sinh thái và duy trì an ninh hệ thống. Tuy nhiên, cũng có cơ chế hủy để duy trì cân bằng sinh thái bằng cách định kỳ hủy một số token.'
    },
    tags: ['supply', 'economics', 'token']
  },
  {
    id: 'q004',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: 'EACO如何连接地球与宇宙？',
      en: 'How does EACO connect Earth and the cosmos?',
      es: '¿Cómo conecta EACO la Tierra con el cosmos?',
      vi: 'EACO kết nối Trái Đất với vũ trụ như thế nào?'
    },
    answer: {
      zh: 'EACO通过"文明协议"的概念连接地球与宇宙，这一概念超越了传统区块链的应用范畴，旨在构建一个能够整合地球资源与太空探索价值的去中心化系统。EACO协议设计了独特的跨维度价值锚定机制，不仅可以锚定地球上的劳动和资源，还为未来太空资源的开发和价值量化提供了基础框架。',
      en: 'EACO connects Earth and the cosmos through the concept of a "civilization protocol," which goes beyond traditional blockchain applications and aims to build a decentralized system that can integrate Earth resources with space exploration value. The EACO protocol has designed a unique cross-dimensional value anchoring mechanism that can not only anchor labor and resources on Earth but also provide a basic framework for the development and value quantification of future space resources.',
      es: 'EACO conecta la Tierra con el cosmos a través del concepto de "protocolo de civilización", que va más allá de las aplicaciones tradicionales de blockchain y pretende construir un sistema descentralizado que pueda integrar los recursos terrestres con el valor de la exploración espacial. El protocolo EACO ha diseñado un mecanismo único de anclaje de valor transdimensional que no solo puede anclar el trabajo y los recursos en la Tierra, sino también proporcionar un marco básico para el desarrollo y la cuantificación del valor de los recursos espaciales futuros.',
      vi: 'EACO kết nối Trái Đất với vũ trụ thông qua khái niệm "giao thức văn minh", khái niệm vượt ra ngoài phạm vi ứng dụng của blockchain truyền thống, nhằm xây dựng một hệ thống phi tập trung có thể tích hợp tài nguyên Trái Đất với giá trị của khám phá không gian. Giao thức EACO đã thiết kế một cơ chế neo giá trị xuyên chiều độc đáo không chỉ có thể neo lao động và tài nguyên trên Trái Đất mà còn cung cấp khung cơ bản cho phát triển và định lượng giá trị của tài nguyên không gian trong tương lai.'
    },
    tags: ['protocol', 'vision', 'future']
  },
  {
    id: 'q005',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: '什么是"文明协议"？',
      en: 'What is a "civilization protocol"?',
      es: '¿Qué es un "protocolo de civilización"?',
      vi: 'Giao thức "văn minh" là gì?'
    },
    answer: {
      zh: '"文明协议"是EACO提出的创新概念，它是一套基于区块链技术的规则体系，旨在促进人类文明的可持续发展。不同于传统的区块链协议仅关注经济交易，文明协议还整合了社会治理、环境保护、文化传承等更广泛的人类文明要素，通过技术手段确保这些要素能够被合理量化和价值化，从而引导人类社会向更可持续的方向发展。',
      en: '"Civilization protocol" is an innovative concept proposed by EACO. It is a set of rules based on blockchain technology aimed at promoting the sustainable development of human civilization. Unlike traditional blockchain protocols that only focus on economic transactions, the civilization protocol also integrates broader elements of human civilization such as social governance, environmental protection, and cultural heritage. Through technical means, it ensures that these elements can be reasonably quantified and valued, thereby guiding human society toward a more sustainable direction.',
      es: '"Protocolo de civilización" es un concepto innovador propuesto por EACO. Es un conjunto de reglas basadas en tecnología blockchain destinadas a promover el desarrollo sostenible de la civilización humana. A diferencia de los protocolos blockchain tradicionales que solo se centran en transacciones económicas, el protocolo de civilización también integra elementos más amplios de la civilización humana como la gobernanza social, la protección ambiental y el patrimonio cultural. Mediante medios técnicos, garantiza que estos elementos puedan cuantificarse y valorarse razonablemente, guiando así a la sociedad humana hacia una dirección más sostenible.',
      vi: '"Giao thức văn minh" là một khái niệm sáng tạo được đề xuất bởi EACO. Đó là một tập hợp các quy tắc dựa trên công nghệ blockchain nhằm thúc đẩy sự phát triển bền vững của văn minh nhân loại. Không giống như các giao thức blockchain truyền thống chỉ tập trung vào các giao dịch kinh tế, giao thức văn minh còn tích hợp các yếu tố rộng hơn của văn minh nhân loại như quản trị xã hội, bảo vệ môi trường và di sản văn hóa. Thông qua các phương tiện kỹ thuật, nó đảm bảo rằng các yếu tố này có thể được định lượng và định giá hợp lý, từ đó hướng dẫn xã hội nhân loại theo hướng bền vững hơn.'
    },
    tags: ['protocol', 'concept', 'innovation']
  },
  {
    id: 'q006',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: 'EACO与稳定币有何不同？',
      en: 'How is EACO different from stablecoins?',
      es: '¿En qué se diferencia EACO de las stablecoins?',
      vi: 'EACO khác gì với stablecoin?'
    },
    answer: {
      zh: 'EACO与传统稳定币有本质区别。稳定币通常与单一法币或一篮子资产挂钩，价值相对稳定但缺乏增长性。而EACO的价值锚定的是全球劳动总量和资源价值，其价值会随着全球经济发展和生态扩大而增长。此外，EACO具有独特的劳动价值量化机制，能够将人类劳动直接转化为数字资产，这是稳定币所不具备的核心功能。',
      en: 'EACO is fundamentally different from traditional stablecoins. Stablecoins are usually pegged to a single fiat currency or a basket of assets, with relatively stable value but lacking growth potential. EACO\'s value is anchored to the total global labor and resource value, and its value will grow with global economic development and ecological expansion. In addition, EACO has a unique labor value quantification mechanism that can directly convert human labor into digital assets, a core function not available in stablecoins.',
      es: 'EACO es fundamentalmente diferente de las stablecoins tradicionales. Las stablecoins suelen estar vinculadas a una sola moneda fiduciaria o a una cesta de activos, con un valor relativamente estable pero careciendo de potencial de crecimiento. El valor de EACO está anclado al trabajo global total y al valor de los recursos, y su valor crecerá con el desarrollo económico global y la expansión ecológica. Además, EACO tiene un mecanismo único de cuantificación del valor laboral que puede convertir directamente el trabajo humano en activos digitales, una función central que no está disponible en las stablecoins.',
      vi: 'EACO khác本质区别 so với stablecoin truyền thống. Stablecoin thường được gắn liền với một đồng tiền pháp định duy nhất hoặc một giỏi tài sản, giá trị tương đối ổn định nhưng thiếu tiềm năng tăng trưởng. Trong khi giá trị của EACO được neo vào tổng lao động toàn cầu và giá trị tài nguyên, giá trị của nó sẽ tăng lên cùng với sự phát triển kinh tế toàn cầu và mở rộng sinh thái. Ngoài ra, EACO có một cơ chế định lượng giá trị lao động độc đáo có thể chuyển đổi trực tiếp lao động con người thành tài sản kỹ thuật số, một chức năng cốt lõi không có ở stablecoin.'
    },
    tags: ['comparison', 'stablecoin', 'value']
  },
  {
    id: 'q007',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: '什么是$e=$eaco模型？',
      en: 'What is the $e=$eaco model?',
      es: '¿Qué es el modelo $e=$eaco?',
      vi: 'Mô hình $e=$eaco là gì?'
    },
    answer: {
      zh: '$e=$eaco模型是EACO协议的核心经济模型，它建立了劳动价值(e)与EACO代币之间的数学映射关系。该模型基于复杂的算法，考虑了劳动时间、劳动强度、技能水平、社会贡献等多个维度，实现了对人类劳动的科学量化。通过这一模型，每个参与者的贡献都能被准确评估并获得相应的EACO奖励，从而实现价值的公平分配。',
      en: 'The $e=$eaco model is the core economic model of the EACO protocol, establishing a mathematical mapping relationship between labor value (e) and EACO tokens. This model is based on complex algorithms, considering multiple dimensions such as labor time, labor intensity, skill level, and social contribution, realizing the scientific quantification of human labor. Through this model, each participant\'s contribution can be accurately evaluated and receive corresponding EACO rewards, thereby achieving fair distribution of value.',
      es: 'El modelo $e=$eaco es el modelo económico central del protocolo EACO, estableciendo una relación de mapeo matemático entre el valor laboral (e) y los tokens EACO. Este modelo se basa en algoritmos complejos, considerando múltiples dimensiones como el tiempo laboral, la intensidad laboral, el nivel de habilidad y la contribución social, realizando la cuantificación científica del trabajo humano. A través de este modelo, la contribución de cada participante puede evaluarse con precisión y recibir recompensas EACO correspondientes, logrando así una distribución justa del valor.',
      vi: 'Mô hình $e=$eaco là mô hình kinh tế cốt lõi của giao thức EACO, thiết lập mối quan hệ ánh xạ toán học giữa giá trị lao động (e) và token EACO. Mô hình này dựa trên các thuật toán phức tạp, xem xét nhiều chiều như thời gian lao động, cường độ lao động, trình độ kỹ năng và đóng góp xã hội, thực hiện định lượng khoa học của lao động con người. Thông qua mô hình này, đóng góp của mỗi người tham gia có thể được đánh giá chính xác và nhận được phần thưởng EACO correspondientes, để đạt được phân phối giá trị công bằng.'
    },
    tags: ['model', 'economy', 'algorithm']
  },
  {
    id: 'q008',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: 'EACO是否具备价值锚定功能？',
      en: 'Does EACO have value anchoring capabilities?',
      es: '¿EACO tiene capacidad de anclaje de valor?',
      vi: 'EACO có khả năng neo giá trị không?'
    },
    answer: {
      zh: '是的，价值锚定是EACO的核心功能之一。EACO采用多维度锚定机制，不仅锚定传统资产如法币、黄金等，还创新性地锚定劳动价值和自然资源。通过去中心化的预言机网络，EACO能够实时获取各类资产价格和劳动价值数据，并通过智能合约自动调整代币价值，确保EACO的价值稳定且具有增长性。',
      en: 'Yes, value anchoring is one of EACO\'s core functions. EACO adopts a multi-dimensional anchoring mechanism that not only anchors traditional assets such as fiat currencies and gold but also innovatively anchors labor value and natural resources. Through a decentralized oracle network, EACO can obtain real-time prices of various assets and labor value data, and automatically adjust token value through smart contracts to ensure EACO\'s value is stable and growing.',
      es: 'Sí, el anclaje de valor es una de las funciones centrales de EACO. EACO adopta un mecanismo de anclaje multidimensional que no solo ancla activos tradicionales como monedas fiduciarias y oro, sino que también ancla innovadoramente el valor laboral y los recursos naturales. A través de una red descentralizada de oráculos, EACO puede obtener precios en tiempo real de various activos y datos de valor laboral, y ajustar automáticamente el valor del token a través de contratos inteligentes para garantizar que el valor de EACO sea estable y creciente.',
      vi: 'Có, neo giá trị là một trong những chức năng cốt lõi của EACO. EACO áp dụng cơ chế neo đa chiều không chỉ neo các tài sản truyền thống như tiền pháp định, vàng và các loại khác mà còn sáng tạo neo giá trị lao động và tài nguyên tự nhiên. Thông qua mạng lưới oracle phi tập trung, EACO có thể nhận được giá cả các loại tài sản và dữ liệu giá trị lao động theo thời gian thực, và tự động điều chỉnh giá trị token thông qua hợp đồng thông minh để đảm bảo giá trị của EACO ổn định và có tăng trưởng.'
    },
    tags: ['anchoring', 'value', 'oracle']
  },
  {
    id: 'q009',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: 'EACO是否可用于跨境结算？',
      en: 'Can EACO be used for cross-border settlement?',
      es: '¿Se puede usar EACO para pagos internacionales?',
      vi: 'EACO có thể dùng để thanh toán xuyên biên giới không?'
    },
    answer: {
      zh: '是的，EACO特别适合跨境结算。由于其基于区块链技术，EACO跨境转账具有速度快、成本低、无需中介等优势。目前EACO已与多个国家的金融机构合作，建立了跨境结算通道，支持多种法币与EACO的直接兑换。此外，EACO的智能合约功能还支持自动执行跨境贸易中的各种条款，大大简化了国际贸易流程。',
      en: 'Yes, EACO is particularly suitable for cross-border settlement. Based on blockchain technology, EACO cross-border transfers offer advantages such as speed, low cost, and no need for intermediaries. Currently, EACO has collaborated with financial institutions in multiple countries to establish cross-border settlement channels, supporting direct exchange between various fiat currencies and EACO. In addition, EACO\'s smart contract function supports the automatic execution of various terms in cross-border trade, greatly simplifying international trade processes.',
      es: 'Sí, EACO es particularmente adecuado para el pago transfronterizo. Basado en tecnología blockchain, las transferencias transfronterizas de EACO ofrecen ventajas como velocidad, bajo costo y no necesidad de intermediarios. Actualmente, EACO ha colaborado con instituciones financieras en múltiples países para establecer canales de pago transfronterizo, admitiendo el intercambio directo entre various monedas fiduciarias y EACO. Además, la función de contrato inteligente de EACO admite la ejecución automática de various términos en el comercio transfronterizo, simplificando greatly los procesos comerciales internacionales.',vi: 'Có, EACO đặc biệt thích hợp để thanh toán xuyên biên giới. Do dựa trên công nghệ blockchain, chuyển tiền xuyên biên giới EACO có ưu điểm như tốc độ nhanh, chi phí thấp, không cần trung gian và các yếu tố khác. Hiện tại EACO đã hợp tác với các tổ chức tài chính ở nhiều quốc gia, thiết lập kênh thanh toán xuyên biên giới, hỗ trợ đổi trực tiếp nhiều đồng tiền pháp định với EACO. Ngoài ra, chức năng hợp đồng thông minh của EACO cũng hỗ trợ tự động thực hiện các điều khoản trong thương mại xuyên biên giới, đã đơn giản hóa quá trình thương mại quốc tế một cách đáng kể.'
    },
    tags: ['application', 'cross-border', 'payment']
  },
  {
    id: 'q010',
    module: 'protocol',
    moduleName: {
      zh: 'EACO协议基础',
      en: 'EACO Protocol Basics',
      es: 'Básicos del protocolo EACO',
      vi: 'Cơ bản về giao thức EACO'
    },
    question: {
      zh: 'EACO是否支持多语言治理？',
      en: 'Does EACO support multilingual governance?',
      es: '¿EACO admite gobernanza multilingüe?',
      vi: 'EACO có hỗ trợ quản trị đa ngôn ngữ không?'
    },
    answer: {
      zh: '是的，EACO支持多语言治理，这是其全球化战略的重要组成部分。EACO协议内置了实时翻译功能，支持全球主要语言，确保不同国家和地区的用户都能参与社区治理。此外，EACO还采用了去中心化的投票机制，社区成员可以用自己熟悉的语言提交提案和参与投票，系统会自动完成语言转换和计票工作，保障全球社区成员的平等参与权。',
      en: 'Yes, EACO supports multilingual governance, which is an important part of its globalization strategy. The EACO protocol has built-in real-time translation functions, supporting major global languages to ensure users from different countries and regions can participate in community governance. In addition, EACO has adopted a decentralized voting mechanism where community members can submit proposals and vote in their familiar language. The system automatically completes language conversion and vote counting, ensuring equal participation rights for global community members.',
      es: 'Sí, EACO admite gobernanza multilingüe, lo cual es una parte importante de su estrategia de globalización. El protocolo EACO tiene funciones de traducción en tiempo real integradas, admitiendo los principales idiomas mundiales para garantizar que los usuarios de differentes países y regiones puedan participar en la gobernanza comunitaria. Además, EACO ha adoptado un mecanismo de votación descentralizado donde los miembros de la comunidad pueden presentar propuestas y votar en su idioma familiar. El sistema completa automáticamente la conversión de idiomas y el recuento de votos, garantizando derechos de participación iguales para los miembros de la comunidad global.',
      vi: 'Có, EACO hỗ trợ quản trị đa ngôn ngữ, đây là một phần quan trọng của chiến lược toàn cầu hóa của nó. Giao thức EACO có các chức năng dịch thuật thời gian thực tích hợp, hỗ trợ các ngôn ngữ chính trên thế giới để đảm bảo người dùng từ các quốc gia và vùng khác nhau có thể tham gia vào quản trị cộng đồng. Ngoài ra, EACO cũng áp dụng cơ chế bỏ phiếu phi tập trung, các thành viên cộng đồng có thể nộp đề xuất và tham gia bỏ phiếu bằng ngôn ngữ quen thuộc của mình, hệ thống sẽ tự động hoàn thành chuyển đổi ngôn ngữ và đếm phiếu, đảm bảo quyền tham gia bình đẳng của các thành viên cộng đồng toàn cầu.'
    },
    tags: ['governance', 'multilingual', 'community']
  },
  
  // 模块2: 钱包与Swap操作
  {
    id: 'q011',
    module: 'wallet',
    moduleName: {
      zh: '钱包与Swap操作',
      en: 'Wallet & Swap Operations',
      es: 'Operaciones de billetera y Swap',
      vi: 'Ví và thao tác Swap'
    },
    question: {
      zh: '如何安装EACO钱包？',
      en: 'How do I install the EACO wallet?',
      es: '¿Cómo instalo la billetera EACO?',
      vi: 'Làm thế nào để cài đặt ví EACO?'
    },
    answer: {
      zh: '安装EACO钱包非常简单，您可以按照以下步骤操作：1. 访问EACO官方网站，在"资源下载"栏目中找到钱包客户端；2. 根据您的操作系统选择相应版本（Windows、Mac、Linux或移动设备）；3. 下载并安装客户端；4. 打开钱包，按照指引创建新钱包或导入已有钱包；5. 备份助记词并妥善保管。安装过程中如遇问题，可以查看官网的详细教程或联系客服支持。',
      en: 'Installing the EACO wallet is very simple. You can follow these steps: 1. Visit the official EACO website and find the wallet client in the "Resource Download" section; 2. Select the appropriate version according to your operating system (Windows, Mac, Linux, or mobile device); 3. Download and install the client; 4. Open the wallet and follow the instructions to create a new wallet or import an existing one; 5. Backup your mnemonic phrase and keep it safe. If you encounter problems during installation, you can check the detailed tutorial on the official website or contact customer support.',
      es: 'Instalar la billetera EACO es muy simple. Puede seguir estos pasos: 1. Visite el sitio web oficial de EACO y encuentre el cliente de billetera en la sección "Descarga de recursos"; 2. Seleccione la versión apropiada según su sistema operativo (Windows, Mac, Linux o dispositivo móvil); 3. Descargue e instale el cliente; 4. Abra la billetera y siga las instrucciones para crear una nueva billetera o importar una existente; 5. Realice una copia de seguridad de su frase mnemotécnica y guárdela en un lugar seguro. Si encuentra problemas durante la instalación, puede consultar el tutorial detallado en el sitio web oficial o contactar al soporte al cliente.',
      vi: 'Cài đặt ví EACO rất đơn giản. Bạn có thể làm theo các bước sau: 1. Truy cập trang web chính thức của EACO và tìm khách hàng ví trong phần "Tải tài nguyên"; 2. Chọn phiên bản thích hợp theo hệ điều hành của bạn (Windows, Mac, Linux hoặc thiết bị di động); 3. Tải xuống và cài đặt khách hàng; 4. Mở ví và làm theo hướng dẫn để tạo ví mới hoặc nhập ví hiện có; 5. Sao lưu cụm từ ghi nhớ của bạn và giữ nó an toàn. Nếu bạn gặp vấn đề trong quá trình cài đặt, bạn có thể kiểm tra hướng dẫn chi tiết trên trang web chính thức hoặc liên hệ hỗ trợ khách hàng.'
    },
    tags: ['wallet', 'installation', 'basic']
  },
  {
    id: 'q012',
    module: 'wallet',
    moduleName: {
      zh: '钱包与Swap操作',
      en: 'Wallet & Swap Operations',
      es: 'Operaciones de billetera y Swap',
      vi: 'Ví và thao tác Swap'
    },
    question: {
      zh: '如何创建EACO地址？',
      en: 'How do I create an EACO address?',
      es: '¿Cómo creo una dirección EACO?',
      vi: 'Làm thế nào để tạo địa chỉ EACO?'
    },
    answer: {
      zh: '创建EACO地址的步骤如下：1. 打开EACO钱包应用，点击"创建新钱包"；2. 仔细阅读并同意服务条款；3. 备份助记词，按照顺序记录并验证；4. 设置钱包密码，建议使用强密码；5. 完成创建后，系统会自动生成您的EACO地址。每个地址都是唯一的，由42位字符组成，以"0x"开头。请确保妥善保管您的助记词和密码，它们是恢复钱包的唯一途径。',
      en: 'The steps to create an EACO address are as follows: 1. Open the EACO wallet application and click "Create New Wallet"; 2. Read and agree to the terms of service carefully; 3. Backup your mnemonic phrase, record and verify it in order; 4. Set a wallet password, preferably a strong password; 5. After completion, the system will automatically generate your EACO address. Each address is unique, consisting of 42 characters starting with "0x". Please ensure you keep your mnemonic phrase and password safe, as they are the only way to recover your wallet.',
      es: 'Los pasos para crear una dirección EACO son los siguientes: 1. Abra la aplicación de billetera EACO y haga clic en "Crear nueva billetera"; 2. Lea y acepte los términos de servicio cuidadosamente; 3. Realice una copia de seguridad de su frase mnemotécnica, regístrela y verifíquela en orden; 4. Establezca una contraseña para la billetera, preferiblemente una contraseña fuerte; 5. Después de completar, el sistema generará automáticamente su dirección EACO. Cada dirección es única, consistiendo en 42 caracteres que comienzan con "0x". Por favor, asegúrese de mantener segura su frase mnemotécnica y contraseña, ya que son la única forma de recuperar su billetera.',
      vi: 'Các bước để tạo địa chỉ EACO như sau: 1. Mở ứng dụng ví EACO và nhấp vào "Tạo ví mới"; 2. Đọc kỹ và đồng ý với các điều khoản dịch vụ; 3. Sao lưu cụm từ ghi nhớ của bạn, ghi lại và xác minh nó theo thứ tự; 4. Đặt mật khẩu ví, tốt nhất là mật khẩu mạnh; 5. Sau khi hoàn thành, hệ thống sẽ tự động tạo địa chỉ EACO của bạn. Mỗi địa chỉ là duy nhất, bao gồm 42 ký tự bắt đầu bằng "0x". Vui lòng đảm bảo bạn giữ cụm từ ghi nhớ và mật khẩu của mình an toàn, vì chúng là cách duy nhất để khôi phục ví của bạn.'
    },
    tags: ['wallet', 'address', 'creation']
  },
  {
    id: 'q013',
    module: 'wallet',
    moduleName: {
      zh: '钱包与Swap操作',
      en: 'Wallet & Swap Operations',
      es: 'Operaciones de billetera y Swap',
      vi: 'Ví và thao tác Swap'
    },
    question: {
      zh: '如何使用EACO Swap？',
      en: 'How do I use EACO Swap?',
      es: '¿Cómo uso EACO Swap?',
      vi: 'Làm thế nào để sử dụng EACO Swap?'
    },
    answer: {
      zh: '使用EACO Swap进行兑换的步骤如下：1. 打开EACO钱包并确保已连接到正确的网络；2. 在钱包首页点击"Swap"按钮；3. 选择要兑换的代币对，例如"EACO/USDT"；4. 输入要兑换的数量，系统会自动显示预计获得的数量；5. 点击"兑换"按钮，确认交易详情；6. 等待区块链确认，通常需要1-3分钟；7. 交易完成后，可在"交易记录"中查看详情。请注意，兑换时会收取0.3%的手续费，用于流动性提供者和系统维护。',
      en: 'The steps to exchange using EACO Swap are as follows: 1. Open the EACO wallet and ensure you are connected to the correct network; 2. Click the "Swap" button on the wallet homepage; 3. Select the token pair to exchange, such as "EACO/USDT"; 4. Enter the amount to exchange, and the system will automatically display the estimated amount to receive; 5. Click the "Exchange" button and confirm transaction details; 6. Wait for blockchain confirmation, usually taking 1-3 minutes; 7. After completion, you can view details in "Transaction History". Note that a 0.3% fee is charged for exchanges, used for liquidity providers and system maintenance.',
      es: 'Los pasos para intercambiar usando EACO Swap son los siguientes: 1. Abra la billetera EACO y asegúrese de estar conectado a la red correcta; 2. Haga clic en el botón "Swap" en la página de inicio de la billetera; 3. Seleccione el par de tokens para intercambiar, como "EACO/USDT"; 4. Ingrese la cantidad a intercambiar, y el sistema mostrará automáticamente la cantidad estimada a recibir; 5. Haga clic en el botón "Intercambiar" y confirme los detalles de la transacción; 6. Espere la confirmación de la blockchain, que suele tardar 1-3 minutos; 7. Después de completarse, puede ver los detalles en "Historial de transacciones". Tenga en cuenta que se cobra una tarifa del 0.3% por los intercambios, utilizada para proveedores de liquidez y mantenimiento del sistema.',
      vi: 'Các bước để đổi quy đổi bằng EACO Swap như sau: 1. Mở ví EACO và đảm bảo bạn đã kết nối với mạng chính xác; 2. Nhấp vào nút "Swap" trên trang chủ ví; 3. Chọn cặp token để đổi, chẳng hạn như "EACO/USDT"; 4. Nhập số lượng để đổi, hệ thống sẽ tự động hiển thị số lượng ước tính nhận được; 5. Nhấp vào nút "Đổi" và xác nhận chi tiết giao dịch; 6. Chờ xác nhận blockchain, thường mất 1-3 phút; 7. Sau khi hoàn thành, bạn có thể xem chi tiết trong "Lịch sử giao dịch". Lưu ý rằng có phí 0.3% được tính khi đổi, dùng cho nhà cung cấp thanh khoản và bảo trì hệ thống.'
    },
    tags: ['swap', 'exchange', 'tutorial']
  }

 
]