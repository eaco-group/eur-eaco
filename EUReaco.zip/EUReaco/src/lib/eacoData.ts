/**
 * EACO模拟数据服务
 * 提供价格数据和历史记录
 */

// 生成随机价格变动
const generatePriceChange = (currentPrice: number): { price: number; change: number } => {
  const changePercent = (Math.random() - 0.5) * 0.02; // -1% 到 1% 的随机变动
  const newPrice = currentPrice * (1 + changePercent);
  return {
    price: newPrice,
    change: changePercent * 100
  };
};

// 获取EACO当前价格（模拟）
export const getEACOPrice = () => {
  // 初始价格设置为1.2欧元左右
  const basePrice = 1.2;
  const storedPrice = localStorage.getItem('eacoPrice');
  const currentPrice = storedPrice ? parseFloat(storedPrice) : basePrice;
  
  const { price, change } = generatePriceChange(currentPrice);
  localStorage.setItem('eacoPrice', price.toString());
  
  return { price, change };
};

// 生成历史价格数据（模拟7天数据）
export const getHistoricalData = () => {
  const data = [];
  const today = new Date();
  
  // 生成过去7天的日期和价格
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(today.getDate() - i);
    
    // 生成一个接近1.2欧元的随机价格，有轻微波动
    const price = 1.15 + Math.random() * 0.1;
    
    data.push({
      date: date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }),
      price: parseFloat(price.toFixed(4))
    });
  }
  
  return data;
};

// 获取EUR兑换EACO的方法
export const getExchangeMethods = () => {
  return [
    {
      id: 1,
      translationKey: "exchange_methods.centralized_exchange",
      stepsKey: "exchange_methods.centralized_exchange_steps",
      platforms: ["Binance", "OKX", "Huobi"]
    },
    {
      id: 2,
      translationKey: "exchange_methods.decentralized_exchange",
      stepsKey: "exchange_methods.decentralized_exchange_steps",
      platforms: ["Meteora", "Orca", "Raydium"]
    },
    {
      id: 3,
      translationKey: "exchange_methods.p2p_trading",
      stepsKey: "exchange_methods.p2p_trading_steps",
      platforms: ["Binance P2P", "OKX P2P"]
    }
  ];
};

// 获取交易链接
export const getTradingLinks = () => {
  return [
    {
      id: 1,
      title: "EACO/USDT",
      description: "Meteora DEX",
      url: "https://app.meteora.ag/dlmm/6ZfCi3qzhgDN1ygHVYXvfsfrwz8ZhQ7hD5mJtjeuUDyE",
      icon: "fa-usd"
    },
    {
      id: 2,
      title: "EACO/USDC",
      description: "Orca Pool",
      url: "https://www.orca.so/pools/Cm6EkxcYNfvxeYDBQ3TGXFqa9NCWvrFKHz4Cfju91dhr",
      icon: "fa-credit-card"
    },
    {
      id: 3,
      title: "EACO/SOL",
      description: "Raydium Swap",
      url: "https://raydium.io/swap/?inputMint=DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH&outputMint=sol",
      icon: "fa-sun"
    },
    {
      id: 4,
      title: "EACO市场数据",
      description: "CoinMarketCap",
      url: "https://dex.coinmarketcap.com/token/solana/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH/",
      icon: "fa-chart-line"
    },
    {
      id: 5,
      title: "EACO价格图表",
      description: "DexScreener",
      url: "https://dexscreener.com/solana/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
      icon: "fa-chart-bar"
    },
    {
      id: 6,
      title: "EACO在OKX",
      description: "OKX Web3",
      url: "https://web3.okx.com/token/solana/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
      icon: "fa-exchange-alt"
    },
    {
      id: 7,
      title: "EACO on Binance",
      description: "Binance Web3",
      url: "https://web3.binance.com/en/token/sol/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
      icon: "fa-exchange-alt"
    }
  ];
};

// 获取社区链接
export const getCommunityLinks = () => {
  return [
    {
      id: 1,
      translationKey: "community_links.official_website",
      url: "https://linktr.ee/web3eaco",
      icon: "fa-globe"
    },
    {
      id: 2,
      name: "Solscan",
      url: "https://solscan.io/token/DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH",
      icon: "fa-search"
    },
    {
      id: 3,
      name: "Twitter",
      url: "https://x.com/eacocc",
      icon: "fa-twitter"
    },
    {
      id: 4,
      translationKey: "community_links.english_telegram",
      url: "https://t.me/e_eacocc",
      icon: "fa-telegram"
    },
    {
      id: 5,
      translationKey: "community_links.chinese_community",
      url: "https://t.me/aieaco",
      icon: "fa-comments"
    },
    {
      id: 6,
      translationKey: "community_links.spanish_community",
      url: "https://t.me/eacoespanish",
      icon: "fa-comments"
    },
    {
      id: 7,
      translationKey: "community_links.eaco_exchange_code",
      url: "https://github.com/eacocc/EACO_Exchange_DApp",
      icon: "fa-github"
    },
    {
      id: 8,
      translationKey: "community_links.chinese_telegram",
      url: "https://t.me/eacocny",
      icon: "fa-comments"
    }
  ];
};