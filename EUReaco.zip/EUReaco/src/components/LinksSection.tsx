import { getTradingLinks } from '@/lib/eacoData';

export default function LinksSection() {
  const tradingLinks = getTradingLinks();
  
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {tradingLinks.map((link) => (
        <a
          key={link.id}
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="group bg-white dark:bg-slate-800 rounded-xl shadow-md p-4 flex items-center transition-all duration-300 hover:shadow-lg"
        >
          <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 mr-4 group-hover:scale-110 transition-transform">
            <i className={`fa-solid ${link.icon} text-xl`}></i>
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
              {link.title}
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">{link.description}</p>
          </div>
          <i className="fa-solid fa-external-link-alt ml-auto text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors"></i>
        </a>
      ))}
    </div>
  );
}