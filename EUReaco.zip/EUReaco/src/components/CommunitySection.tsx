import { getCommunityLinks } from '@/lib/eacoData';
import { useLanguage } from '@/contexts/languageContext.tsx';

export default function CommunitySection() {
  const communityLinks = getCommunityLinks();
  const { t } = useLanguage();
  
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {communityLinks.map((link) => (
        <a
          key={link.id}
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 flex flex-col items-center justify-center text-center transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
        >
          <div className="w-14 h-14 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 text-2xl mb-4 group-hover:scale-110 transition-transform">
            <i className={`fa-brands ${link.icon}`}></i>
          </div>
          <h3 className="font-semibold text-slate-800 dark:text-slate-200 mb-1">
            {link.translationKey ? t(link.translationKey) : link.name}
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-full">
            {new URL(link.url).hostname}
          </span>
        </a>
      ))}
    </div>
  );
}