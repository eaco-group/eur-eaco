import { cn } from "@/lib/utils";

interface PriceCardProps {
  title: string;
  value: string;
  change?: number;
  icon: string;
}

export default function PriceCard({ title, value, change, icon }: PriceCardProps) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-300">{title}</h3>
        <i className={`fa-solid ${icon} text-blue-600 dark:text-blue-400 text-xl`}></i>
      </div>
      <div className="text-2xl font-bold mb-2">{value}</div>
      {change !== undefined && (
        <div className={cn(
          "flex items-center text-sm font-medium",
          change > 0 ? "text-green-500" : change < 0 ? "text-red-500" : "text-slate-500"
        )}>
          {change > 0 ? (
            <i className="fa-solid fa-caret-up mr-1"></i>
          ) : change < 0 ? (
            <i className="fa-solid fa-caret-down mr-1"></i>
          ) : (
            <i className="fa-solid fa-minus mr-1"></i>
          )}
          {Math.abs(change).toFixed(2)}%
        </div>
      )}
    </div>
  );
}