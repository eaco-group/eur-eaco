import { getExchangeMethods } from '@/lib/eacoData';
import { useLanguage } from '@/contexts/languageContext.tsx';

export default function ExchangeMethods() {
  const methods = getExchangeMethods();
  const { t } = useLanguage();
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {methods.map((method) => (
        <div 
          key={method.id}
          className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl"
        >
          <div className="bg-blue-600 dark:bg-blue-700 p-4">
            <h3 className="text-xl font-bold text-white">{t(method.translationKey)}</h3>
          </div>
          <div className="p-6">
            <h4 className="font-semibold mb-2 text-slate-700 dark:text-slate-300">{t('exchange_methods.supported_platforms')}:</h4>
            <ol className="list-decimal list-inside space-y-2 mb-6 text-slate-600 dark:text-slate-400">
              {t(method.stepsKey, { returnObjects: true }).map((step: string, index: number) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
            
            <h4 className="font-semibold mb-2 text-slate-700 dark:text-slate-300">{t('exchange_methods.supported_platforms')}:</h4>
            <div className="flex flex-wrap gap-2">
              {method.platforms.map((platform, index) => (
                <span 
                  key={index}
                  className="bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200 px-3 py-1 rounded-full text-sm"
                >
                  {platform}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}