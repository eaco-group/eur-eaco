import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import en from '@/lib/locales/en.json';
import de from '@/lib/locales/de.json';
import fr from '@/lib/locales/fr.json';
import es from '@/lib/locales/es.json';
import ru from '@/lib/locales/ru.json';
import pl from '@/lib/locales/pl.json';
import tr from '@/lib/locales/tr.json';

// Define supported languages
export type LanguageCode = 'en' | 'de' | 'fr' | 'es' | 'ru' | 'pl' | 'tr';

// Language names for display
export const languageNames = {
  en: 'English',
  de: 'Deutsch',
  fr: 'Français',
  es: 'Español',
  ru: 'Русский',
  pl: 'Polski',
  tr: 'Türkçe'
};

// Language flags using Font Awesome icons
export const languageFlags = {
  en: 'fa-flag-us',
  de: 'fa-flag-de',
  fr: 'fa-flag-fr',
  es: 'fa-flag-es',
  ru: 'fa-flag-ru',
  pl: 'fa-flag-pl',
  tr: 'fa-flag-tr'
};

// Translation type
type Translation = typeof en;

// Create translations object
const translations: Record<LanguageCode, Translation> = {
  en,
  de,
  fr,
  es,
  ru,
  pl,
  tr
};

// Create context type
interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, options?: { returnObjects?: boolean }) => string | string[];
}

// Create context
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Provider component
export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<LanguageCode>('en');
  
  // Load saved language from localStorage on mount
  useEffect(() => {
    const savedLang = localStorage.getItem('preferredLanguage') as LanguageCode;
    if (savedLang && Object.keys(languageNames).includes(savedLang)) {
      setLanguage(savedLang);
    } else {
      // Fallback to browser language if available
      const browserLang = navigator.language.split('-')[0] as LanguageCode;
      if (Object.keys(languageNames).includes(browserLang)) {
        setLanguage(browserLang);
      }
    }
  }, []);
  
  // Save language preference to localStorage
  useEffect(() => {
    localStorage.setItem('preferredLanguage', language);
  }, [language]);
  
  // Translation function
  const t = (key: string, options: { returnObjects?: boolean } = {}): string | string[] => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key; // Return key if translation not found
      }
    }
    
    if (options.returnObjects && Array.isArray(value)) {
      return value;
    }
    
    return Array.isArray(value) ? value.join(', ') : value;
  };
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

// Custom hook for using language context
export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}