﻿#Project Number: Euro eaco 01

This project is led by the EUR eaco group（ https://github.com/eaco-group/eur-eaco ）Create

[* * Project Address * *]（ https://github.com/eaco-group/eur-eaco )

##Local development

###Environmental preparation

-Install [Node. js]

( https://nodejs.org/en )
-Install [pnpm]（ https://pnpm.io/installation )

###Operation steps

-Install dependencies

```sh
pnpm 

install
```

-Start Dev Server

```sh
pnpm run dev
```

-Accessing in browser http://localhost:3000
